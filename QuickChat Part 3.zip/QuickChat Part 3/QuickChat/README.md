# QuickChat - PROG5121 PoE

**Student:** Arehone Nengovhela  
**Student Number:** ST10532019  
**Module:** PROG5121p/w - Programming 1A  

---

## Project Structure

```
QuickChat/
├── src/
│   ├── main/java/quickchat/
│   │   ├── Main.java       — App entry point (all 3 parts)
│   │   ├── Login.java      — Part 1: Registration & Login
│   │   └── Message.java    — Part 2 & 3: Messaging features
│   └── test/java/quickchat/
│       ├── LoginTest.java  — Unit tests for Part 1
│       └── MessageTest.java — Unit tests for Parts 2 & 3
├── .github/workflows/
│   └── TestJava.yml        — GitHub Actions CI/CD
├── pom.xml                 — Maven build file
└── README.md
```

---

## How to Run

### In NetBeans:
1. Open NetBeans → File → Open Project → select the QuickChat folder
2. NetBeans will detect it as a Maven project
3. Right-click project → Run

### From terminal:
```bash
mvn compile exec:java -Dexec.mainClass="quickchat.Main"
```

### Run tests:
```bash
mvn test
```

---

## GitHub Setup (required — -5% if missing)

1. Create a new repo on GitHub (use your IIE Connect account)
2. In your project folder run:
```bash
git init
git add .
git commit -m "Initial commit - Part 1 Registration and Login"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/QuickChat.git
git push -u origin main
```
3. Make at least **6 commits per part** as you build features
4. GitHub Actions will automatically run your tests on every push

---

## Features

### Part 1 — Registration & Login
- Username validation (underscore required, max 5 chars)
- Password complexity (8+ chars, capital, number, special char)
- SA cell phone validation (international format +27XXXXXXXXX)
- Login with stored credentials

### Part 2 — Send Messages
- Welcome to QuickChat menu (options 1-3)
- For loop to enter set number of messages
- Auto-generated 10-digit Message ID
- Message Hash (e.g. 00:0:HITONIGHT)
- Send / Disregard / Store options
- Messages stored to JSON file

### Part 3 — Store Data & Display Report
- Arrays: Sent, Disregarded, Stored, Hashes, IDs
- Stored Messages menu (option 4)
- Display senders/recipients
- Find longest message
- Search by Message ID
- Search by recipient
- Delete by hash
- Full message report
- Read JSON back into array
