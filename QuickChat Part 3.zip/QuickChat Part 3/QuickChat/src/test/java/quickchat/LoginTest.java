package quickchat;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Login class.
 * Uses exact test data as specified in the assignment.
 *
 * @author Arehone Nengovhela
 */
public class LoginTest {

    // ===================== USERNAME TESTS =====================

    @Test
    public void testUsernameCorrectlyFormatted() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        assertTrue(login.checkUserName(),
                "Username 'kyl_1' should be correctly formatted (has underscore, <= 5 chars)");
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {
        Login login = new Login("kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        assertFalse(login.checkUserName(),
                "Username 'kyle!!!!!!!' should fail (no underscore, more than 5 chars)");
    }

    // ===================== PASSWORD TESTS =====================

    @Test
    public void testPasswordMeetsComplexity() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        assertTrue(login.checkPasswordComplexity(),
                "Password 'Ch&&sec@ke99!' should meet complexity requirements");
    }

    @Test
    public void testPasswordDoesNotMeetComplexity() {
        Login login = new Login("kyl_1", "password", "+27838968976", "Arehone", "Nengovhela");
        assertFalse(login.checkPasswordComplexity(),
                "Password 'password' should fail complexity check");
    }

    // ===================== CELL PHONE TESTS =====================

    @Test
    public void testCellPhoneCorrectlyFormatted() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        assertTrue(login.checkCellPhoneNumber(),
                "Cell phone '+27838968976' should be correctly formatted");
    }

    @Test
    public void testCellPhoneIncorrectlyFormatted() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "08966553", "Arehone", "Nengovhela");
        assertFalse(login.checkCellPhoneNumber(),
                "Cell phone '08966553' should fail (no international code)");
    }

    // ===================== REGISTER USER TESTS (assertEquals) =====================

    @Test
    public void testRegisterUserUsernameSuccessfullyCaptured() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        String result = login.registerUser();
        assertTrue(result.contains("Username successfully captured."),
                "Registration should confirm username captured");
    }

    @Test
    public void testRegisterUserUsernameNotCorrectlyFormatted() {
        Login login = new Login("kyle!!!!!!!", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        String result = login.registerUser();
        assertEquals("Username is not correctly formatted; please ensure that your username " +
                     "contains an underscore and is no more than five characters in length.",
                result,
                "Should return username format error message");
    }

    @Test
    public void testRegisterUserPasswordSuccessfullyCaptured() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        String result = login.registerUser();
        assertTrue(result.contains("Password successfully captured."),
                "Registration should confirm password captured");
    }

    @Test
    public void testRegisterUserPasswordNotCorrectlyFormatted() {
        Login login = new Login("kyl_1", "password", "+27838968976", "Arehone", "Nengovhela");
        String result = login.registerUser();
        assertEquals("Password is not correctly formatted; please ensure that the password " +
                     "contains at least eight characters, a capital letter, a number, and a special character.",
                result,
                "Should return password format error message");
    }

    @Test
    public void testRegisterUserCellSuccessfullyCaptured() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        String result = login.registerUser();
        assertTrue(result.contains("Cell phone number successfully added."),
                "Registration should confirm cell number added");
    }

    @Test
    public void testRegisterUserCellIncorrectlyFormatted() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "08966553", "Arehone", "Nengovhela");
        String result = login.registerUser();
        assertEquals("Cell phone number incorrectly formatted or does not contain international code.",
                result,
                "Should return cell phone format error message");
    }

    // ===================== LOGIN TESTS (assertTrue/assertFalse) =====================

    @Test
    public void testLoginSuccessful() {
        // Register first
        Login reg = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        reg.registerUser();

        // Now login
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        assertTrue(login.loginUser(), "Login should succeed with correct credentials");
    }

    @Test
    public void testLoginFailed() {
        // Register first
        Login reg = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        reg.registerUser();

        // Wrong password
        Login login = new Login("kyl_1", "wrongPass1!", "+27838968976", "Arehone", "Nengovhela");
        assertFalse(login.loginUser(), "Login should fail with wrong credentials");
    }

    @Test
    public void testReturnLoginStatusSuccess() {
        Login reg = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        reg.registerUser();

        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        String status = login.returnLoginStatus();
        assertEquals("Welcome Arehone Nengovhela it is great to see you again.", status,
                "Login status should return welcome message");
    }

    @Test
    public void testReturnLoginStatusFailed() {
        Login reg = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Arehone", "Nengovhela");
        reg.registerUser();

        Login login = new Login("kyl_1", "wrongPass1!", "+27838968976", "Arehone", "Nengovhela");
        String status = login.returnLoginStatus();
        assertEquals("Username or password incorrect, please try again.", status,
                "Login status should return error message");
    }
}
