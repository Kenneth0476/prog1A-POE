package quickchat;

/**
 * Login class handles user registration and login functionality.
 * Validates username, password complexity, and SA cell phone numbers.
 *
 * @author Arehone Nengovhela
 * @version 1.0
 */
public class Login {

    private String username;
    private String password;
    private String cellPhoneNumber;
    private String firstName;
    private String lastName;

    // Stored credentials after successful registration
    private static String registeredUsername;
    private static String registeredPassword;
    private static String registeredFirstName;
    private static String registeredLastName;

    /**
     * Constructor for Login.
     *
     * @param username      the username entered
     * @param password      the password entered
     * @param cellPhoneNumber the cell phone number entered
     * @param firstName     the user's first name
     * @param lastName      the user's last name
     */
    public Login(String username, String password, String cellPhoneNumber,
                 String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * Checks that the username contains an underscore and
     * is no more than five characters long.
     *
     * @return true if username is valid, false otherwise
     */
    public boolean checkUserName() {
        return username.contains("_") && username.length() <= 5;
    }

    /**
     * Checks that the password meets complexity requirements:
     * at least 8 characters, contains a capital letter,
     * contains a number, and contains a special character.
     *
     * @return true if password meets requirements, false otherwise
     */
    public boolean checkPasswordComplexity() {
        if (password.length() < 8) {
            return false;
        }
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCapital = true;
            if (Character.isDigit(c)) hasNumber = true;
            if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasCapital && hasNumber && hasSpecial;
    }

    /**
     * Checks that the cell phone number contains the international
     * country code and is no more than ten characters long (excluding +).
     *
     * Cell phone regex source:
     * https://regexr.com/3c53v - adapted for South African international format
     *
     * @return true if cell phone number is valid, false otherwise
     */
    public boolean checkCellPhoneNumber() {
        // Must start with + followed by country code and number, total <= 12 chars
        // SA format: +27 followed by 9 digits = +27XXXXXXXXX (12 chars)
        String regex = "^\\+[0-9]{10}$";
        return cellPhoneNumber.matches(regex);
    }

    /**
     * Registers the user by validating all fields and returning
     * the appropriate registration message.
     *
     * @return registration status message
     */
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username " +
                   "contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password " +
                   "contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        // Store credentials for login use
        registeredUsername = this.username;
        registeredPassword = this.password;
        registeredFirstName = this.firstName;
        registeredLastName = this.lastName;

        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }

    /**
     * Verifies that the login details entered match the registered details.
     *
     * @return true if login is successful, false otherwise
     */
    public boolean loginUser() {
        return username.equals(registeredUsername) && password.equals(registeredPassword);
    }

    /**
     * Returns the login status message based on whether login was successful.
     *
     * @return welcome message or error message
     */
    public String returnLoginStatus() {
        if (loginUser()) {
            return "Welcome " + registeredFirstName + " " + registeredLastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Getters for testing
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getCellPhoneNumber() { return cellPhoneNumber; }
    public static String getRegisteredFirstName() { return registeredFirstName; }
    public static String getRegisteredLastName() { return registeredLastName; }
    public static String getRegisteredUsername() { return registeredUsername; }
    public static String getRegisteredPassword() { return registeredPassword; }
}
