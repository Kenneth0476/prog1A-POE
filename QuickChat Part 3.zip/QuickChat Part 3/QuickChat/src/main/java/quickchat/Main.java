package quickchat;

import java.util.Scanner;

/**
 * Main class — entry point for the QuickChat console application.
 *
 * @author Arehone Nengovhela
 * @version 1.0
 */
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("===== QUICKCHAT REGISTRATION =====");

        // --- REGISTRATION ---
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter Username (must contain _ and be max 5 characters): ");
        String username = scanner.nextLine();

        System.out.print("Enter Password (min 8 chars, capital letter, number, special character): ");
        String password = scanner.nextLine();

        System.out.print("Enter Cell Phone Number (international format e.g. +27XXXXXXXXX): ");
        String cellPhone = scanner.nextLine();

        Login login = new Login(username, password, cellPhone, firstName, lastName);
        String regResult = login.registerUser();
        System.out.println(regResult);

        if (!regResult.contains("successfully")) {
            System.out.println("Registration failed. Please restart and try again.");
            return;
        }

        // --- LOGIN ---
        System.out.println("\n===== QUICKCHAT LOGIN =====");
        System.out.print("Enter Username: ");
        String loginUser = scanner.nextLine();

        System.out.print("Enter Password: ");
        String loginPass = scanner.nextLine();

        Login loginAttempt = new Login(loginUser, loginPass, cellPhone, firstName, lastName);
        System.out.println(loginAttempt.returnLoginStatus());

        if (!loginAttempt.loginUser()) {
            System.out.println("Login failed. Exiting.");
            return;
        }

        // --- MAIN MENU ---
        System.out.println("\nWelcome to QuickChat.");

        System.out.print("How many messages do you want to send? ");
        int numMessages = Integer.parseInt(scanner.nextLine().trim());

        boolean running = true;

        while (running) {
            System.out.println("\n===== MAIN MENU =====");
            System.out.println("1) Send Messages");
            System.out.println("2) Show Recently Sent Messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            System.out.print("Choose an option: ");

            String menuChoice = scanner.nextLine().trim();

            switch (menuChoice) {
                case "1":
                    // --- SEND MESSAGES (for loop) ---
                    for (int i = 1; i <= numMessages; i++) {
                        System.out.println("\n--- Message " + i + " of " + numMessages + " ---");

                        System.out.print("Enter recipient cell number (+27XXXXXXXXX): ");
                        String recipient = scanner.nextLine();

                        System.out.print("Enter message (max 250 characters): ");
                        String messageText = scanner.nextLine();

                        // Validate message length
                        String lengthCheck = Message.validateMessageLength(messageText);
                        if (!lengthCheck.equals("Message ready to send.")) {
                            System.out.println(lengthCheck);
                            i--; // redo this message
                            continue;
                        }

                        Message msg = new Message(i, recipient, messageText);

                        // Validate recipient
                        System.out.println(msg.checkRecipientCell());
                        if (!msg.checkRecipientCell().contains("successfully")) {
                            i--;
                            continue;
                        }

                        System.out.println("Message ID generated: " + msg.getMessageID());
                        System.out.println("Message Hash: " + msg.getMessageHash());

                        System.out.println("\nWhat would you like to do?");
                        System.out.println("1) Send Message");
                        System.out.println("2) Disregard Message");
                        System.out.println("3) Store Message to send later");
                        System.out.print("Choose: ");
                        int sendChoice = Integer.parseInt(scanner.nextLine().trim());

                        System.out.println(msg.SentMessage(sendChoice));

                        // Display message details
                        System.out.println("\n--- Message Details ---");
                        System.out.println("Message ID   : " + msg.getMessageID());
                        System.out.println("Message Hash : " + msg.getMessageHash());
                        System.out.println("Recipient    : " + msg.getRecipient());
                        System.out.println("Message      : " + msg.getMessageText());
                    }

                    System.out.println("\nTotal messages sent: " + Message.returnTotalMessages());
                    System.out.println(Message.printMessages());
                    break;

                case "2":
                    System.out.println("Coming Soon.");
                    break;

                case "3":
                    running = false;
                    System.out.println("Goodbye!");
                    break;

                case "4":
                    // --- STORED MESSAGES MENU ---
                    boolean storedMenu = true;
                    while (storedMenu) {
                        System.out.println("\n===== STORED MESSAGES =====");
                        System.out.println("a) Display sender and recipient of all stored messages");
                        System.out.println("b) Display the longest stored message");
                        System.out.println("c) Search for a message by ID");
                        System.out.println("d) Search all messages for a particular recipient");
                        System.out.println("e) Delete a message using message hash");
                        System.out.println("f) Display report of all stored messages");
                        System.out.println("x) Back to main menu");
                        System.out.print("Choose: ");
                        String storeChoice = scanner.nextLine().trim().toLowerCase();

                        switch (storeChoice) {
                            case "a":
                                Message.displayStoredMessageSenders();
                                break;
                            case "b":
                                Message.displayLongestMessage();
                                break;
                            case "c":
                                System.out.print("Enter Message ID to search: ");
                                String searchID = scanner.nextLine();
                                Message.searchByMessageID(searchID);
                                break;
                            case "d":
                                System.out.print("Enter recipient number to search: ");
                                String recipientSearch = scanner.nextLine();
                                Message.searchByRecipient(recipientSearch);
                                break;
                            case "e":
                                System.out.print("Enter message hash to delete: ");
                                String hash = scanner.nextLine();
                                Message.deleteByHash(hash);
                                break;
                            case "f":
                                Message.displayReport();
                                break;
                            case "x":
                                storedMenu = false;
                                break;
                            default:
                                System.out.println("Invalid option.");
                        }
                    }
                    break;

                default:
                    System.out.println("Invalid option. Please choose 1, 2, 3, or 4.");
            }
        }

        scanner.close();
    }
}
