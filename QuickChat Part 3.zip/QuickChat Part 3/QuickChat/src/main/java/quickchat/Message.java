package quickchat;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * Message class handles creating, sending, storing, and managing messages.
 * JSON storage implemented using json-simple library.
 * Source: https://code.google.com/archive/p/json-simple/
 *
 * @author Arehone Nengovhela
 * @version 1.0
 */
public class Message {

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;

    // Arrays to store messages by category
    private static ArrayList<String> sentMessages = new ArrayList<>();
    private static ArrayList<String> disregardedMessages = new ArrayList<>();
    private static ArrayList<String> storedMessages = new ArrayList<>();
    private static ArrayList<String> messageHashes = new ArrayList<>();
    private static ArrayList<String> messageIDs = new ArrayList<>();
    private static ArrayList<String> sentRecipients = new ArrayList<>();

    private static int totalMessagesSent = 0;
    private static final String JSON_FILE = "stored_messages.json";

    /**
     * Constructor for Message.
     *
     * @param messageNumber the sequential number of this message
     * @param recipient     the recipient cell phone number
     * @param messageText   the message content
     */
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    /**
     * Generates a random 10-digit message ID.
     *
     * @return 10-digit message ID as a String
     */
    private String generateMessageID() {
        Random rand = new Random();
        long id = (long) (rand.nextDouble() * 9_000_000_000L) + 1_000_000_000L;
        return String.valueOf(id);
    }

    /**
     * Checks that the message ID is not more than ten characters long.
     *
     * @return true if message ID is valid, false otherwise
     */
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    /**
     * Checks that the recipient cell number is no more than ten characters
     * and starts with an international code (+).
     *
     * Reuses the same regex logic from Login.checkCellPhoneNumber().
     * Source: same regex reference as Login class.
     *
     * @return appropriate message string
     */
    public String checkRecipientCell() {
        String regex = "^\\+[0-9]{10}$";
        if (recipient.matches(regex)) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. " +
                   "Please correct the number and try again.";
        }
    }

    /**
     * Creates and returns the message hash.
     * Format: first two digits of messageID + ":" + messageNumber + ":" +
     *         first word of message in caps + last word of message in caps.
     * Example: 00:0:HITHANKS
     *
     * @return message hash string in all caps
     */
    public String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        String hash = firstTwo + ":" + messageNumber + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }

    /**
     * Allows the user to choose whether to send, disregard, or store the message.
     * Returns the appropriate status message.
     *
     * @param choice 1 = Send, 2 = Disregard, 3 = Store
     * @return status message
     */
    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                sentMessages.add(messageText);
                sentRecipients.add(recipient);
                messageHashes.add(messageHash);
                messageIDs.add(messageID);
                totalMessagesSent++;
                return "Message successfully sent.";
            case 2:
                disregardedMessages.add(messageText);
                return "Press 0 to delete the message.";
            case 3:
                storedMessages.add(messageText);
                messageHashes.add(messageHash);
                messageIDs.add(messageID);
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid option.";
        }
    }

    /**
     * Returns all messages sent during the session.
     *
     * @return formatted string of all sent messages
     */
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages sent yet.";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("\n--- Sent Messages ---\n");
        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append("Message ").append(i + 1).append(": ").append(sentMessages.get(i)).append("\n");
        }
        return sb.toString();
    }

    /**
     * Returns the total number of messages sent.
     *
     * @return total sent message count
     */
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    /**
     * Stores the message in a JSON file.
     * Source: https://code.google.com/archive/p/json-simple/ (json-simple library)
     */
    @SuppressWarnings("unchecked")
    public void storeMessage() {
        JSONArray jsonArray = new JSONArray();

        // Load existing data first
        JSONParser parser = new JSONParser();
        try (FileReader reader = new FileReader(JSON_FILE)) {
            Object obj = parser.parse(reader);
            jsonArray = (JSONArray) obj;
        } catch (Exception e) {
            // File doesn't exist yet or is empty — start fresh
        }

        // Add new message
        JSONObject msgObj = new JSONObject();
        msgObj.put("messageID", messageID);
        msgObj.put("messageNumber", messageNumber);
        msgObj.put("recipient", recipient);
        msgObj.put("messageText", messageText);
        msgObj.put("messageHash", messageHash);
        jsonArray.add(msgObj);

        // Write back to file
        try (FileWriter writer = new FileWriter(JSON_FILE)) {
            writer.write(jsonArray.toJSONString());
        } catch (IOException e) {
            System.out.println("Error saving message to JSON: " + e.getMessage());
        }
    }

    /**
     * Reads stored messages from JSON file into the storedMessages array.
     * Source: https://code.google.com/archive/p/json-simple/ (json-simple library)
     */
    public static void loadStoredMessagesFromJSON() {
        JSONParser parser = new JSONParser();
        try (FileReader reader = new FileReader(JSON_FILE)) {
            JSONArray jsonArray = (JSONArray) parser.parse(reader);
            storedMessages.clear();
            for (Object obj : jsonArray) {
                JSONObject msgObj = (JSONObject) obj;
                storedMessages.add((String) msgObj.get("messageText"));
            }
            System.out.println("Stored messages loaded from JSON successfully.");
        } catch (Exception e) {
            System.out.println("No stored messages file found or error reading file.");
        }
    }

    /**
     * Validates that message text does not exceed 250 characters.
     *
     * @param text the message text to check
     * @return "Message ready to send." or error message with character excess
     */
    public static String validateMessageLength(String text) {
        if (text.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = text.length() - 250;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        }
    }

    // ===================== PART 3 FEATURES =====================

    /**
     * Displays sender and recipient of all stored messages.
     */
    public static void displayStoredMessageSenders() {
        System.out.println("\n--- Stored Messages: Sender & Recipient ---");
        JSONParser parser = new JSONParser();
        try (FileReader reader = new FileReader(JSON_FILE)) {
            JSONArray jsonArray = (JSONArray) parser.parse(reader);
            if (jsonArray.isEmpty()) {
                System.out.println("No stored messages.");
                return;
            }
            for (Object obj : jsonArray) {
                JSONObject msgObj = (JSONObject) obj;
                System.out.println("Sender: Arehone Nengovhela | Recipient: " + msgObj.get("recipient"));
            }
        } catch (Exception e) {
            System.out.println("No stored messages found.");
        }
    }

    /**
     * Displays the longest stored message.
     */
    public static void displayLongestMessage() {
        System.out.println("\n--- Longest Stored Message ---");
        JSONParser parser = new JSONParser();
        try (FileReader reader = new FileReader(JSON_FILE)) {
            JSONArray jsonArray = (JSONArray) parser.parse(reader);
            String longest = "";
            for (Object obj : jsonArray) {
                JSONObject msgObj = (JSONObject) obj;
                String text = (String) msgObj.get("messageText");
                if (text.length() > longest.length()) {
                    longest = text;
                }
            }
            if (longest.isEmpty()) {
                System.out.println("No stored messages.");
            } else {
                System.out.println("Longest message: " + longest);
            }
        } catch (Exception e) {
            System.out.println("No stored messages found.");
        }
    }

    /**
     * Searches for a message by ID and displays recipient and message.
     *
     * @param searchID the message ID to search for
     */
    public static void searchByMessageID(String searchID) {
        System.out.println("\n--- Search by Message ID ---");
        JSONParser parser = new JSONParser();
        try (FileReader reader = new FileReader(JSON_FILE)) {
            JSONArray jsonArray = (JSONArray) parser.parse(reader);
            boolean found = false;
            for (Object obj : jsonArray) {
                JSONObject msgObj = (JSONObject) obj;
                if (msgObj.get("messageID").equals(searchID)) {
                    System.out.println("Recipient: " + msgObj.get("recipient"));
                    System.out.println("Message: " + msgObj.get("messageText"));
                    found = true;
                }
            }
            if (!found) System.out.println("Message ID not found.");
        } catch (Exception e) {
            System.out.println("No stored messages found.");
        }
    }

    /**
     * Searches all messages stored or sent for a particular recipient.
     *
     * @param recipientNumber the recipient cell number to search
     */
    public static void searchByRecipient(String recipientNumber) {
        System.out.println("\n--- Messages for Recipient: " + recipientNumber + " ---");
        JSONParser parser = new JSONParser();
        try (FileReader reader = new FileReader(JSON_FILE)) {
            JSONArray jsonArray = (JSONArray) parser.parse(reader);
            boolean found = false;
            for (Object obj : jsonArray) {
                JSONObject msgObj = (JSONObject) obj;
                if (msgObj.get("recipient").equals(recipientNumber)) {
                    System.out.println(msgObj.get("messageText"));
                    found = true;
                }
            }
            if (!found) System.out.println("No messages found for this recipient.");
        } catch (Exception e) {
            System.out.println("No stored messages found.");
        }
    }

    /**
     * Deletes a message from the JSON file using the message hash.
     *
     * @param hash the message hash to delete
     */
    @SuppressWarnings("unchecked")
    public static void deleteByHash(String hash) {
        JSONParser parser = new JSONParser();
        JSONArray jsonArray = new JSONArray();
        boolean found = false;
        String deletedMessage = "";

        try (FileReader reader = new FileReader(JSON_FILE)) {
            jsonArray = (JSONArray) parser.parse(reader);
        } catch (Exception e) {
            System.out.println("No stored messages found.");
            return;
        }

        JSONArray updated = new JSONArray();
        for (Object obj : jsonArray) {
            JSONObject msgObj = (JSONObject) obj;
            if (msgObj.get("messageHash").equals(hash)) {
                found = true;
                deletedMessage = (String) msgObj.get("messageText");
            } else {
                updated.add(msgObj);
            }
        }

        if (found) {
            try (FileWriter writer = new FileWriter(JSON_FILE)) {
                writer.write(updated.toJSONString());
                System.out.println("Message: \"" + deletedMessage + "\" successfully deleted.");
            } catch (IOException e) {
                System.out.println("Error updating JSON file.");
            }
        } else {
            System.out.println("Hash not found.");
        }
    }

    /**
     * Displays a full report of all stored messages including
     * Message Hash, Recipient, and Message.
     */
    public static void displayReport() {
        System.out.println("\n========== MESSAGE REPORT ==========");
        JSONParser parser = new JSONParser();
        try (FileReader reader = new FileReader(JSON_FILE)) {
            JSONArray jsonArray = (JSONArray) parser.parse(reader);
            if (jsonArray.isEmpty()) {
                System.out.println("No messages to report.");
                return;
            }
            for (Object obj : jsonArray) {
                JSONObject msgObj = (JSONObject) obj;
                System.out.println("Message Hash : " + msgObj.get("messageHash"));
                System.out.println("Recipient    : " + msgObj.get("recipient"));
                System.out.println("Message      : " + msgObj.get("messageText"));
                System.out.println("------------------------------------");
            }
        } catch (Exception e) {
            System.out.println("No stored messages found.");
        }
        System.out.println("====================================");
    }

    // Getters
    public String getMessageID() { return messageID; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }
    public int getMessageNumber() { return messageNumber; }
    public static ArrayList<String> getSentMessages() { return sentMessages; }
    public static ArrayList<String> getDisregardedMessages() { return disregardedMessages; }
    public static ArrayList<String> getStoredMessages() { return storedMessages; }
    public static ArrayList<String> getMessageHashes() { return messageHashes; }
    public static ArrayList<String> getMessageIDs() { return messageIDs; }
}
